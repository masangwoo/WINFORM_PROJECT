﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEV_Form
{
    public interface ChildInterface
    {
        void Inquire();
        void DoNew();
        void Delete();
        void Save();

    }
}
