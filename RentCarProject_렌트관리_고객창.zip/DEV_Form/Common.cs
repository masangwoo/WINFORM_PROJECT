﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEV_Form
{
    public class Common
    {
        public static string LogInID = string.Empty;
        public static string LogInName = string.Empty;
        public static string Db = "Data Source=222.235.141.8; Initial Catalog=AppDev; User ID=kfqs1; Password=1234";
    }
}
